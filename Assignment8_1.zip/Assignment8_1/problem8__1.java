package Assignment8_1;

public class problem8__1 {

	public static void main(String args[])

	{

	Counter counter = new Counter(25);

	counter.run();

	}



	}
