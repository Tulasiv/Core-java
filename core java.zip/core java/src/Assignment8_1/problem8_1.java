package Assignment8_1;


import java.lang.Runnable;
public class problem8_1 {

	private int x;

	public problem8_1(int X) { x=X; }

	public int GetX() { return(x); }



	public problem8_1(problem8_1 s) { this.x = s.GetX(); }

	}



	class Printer implements Runnable

	{

	private problem8_1 storage;



	Printer(problem8_1 s) { storage = new problem8_1(s); }



	public void run()

	{

	System.out.println(storage.GetX());

	}



	}



	class Counter implements Runnable

	{

	private int N;



	public Counter(int n) { N=n; }

	public int GetN() { return(N); }



	public void run()

	{

	for (int iLoop=1; iLoop<=N; iLoop++)

	{

	problem8_1 storage = new problem8_1(iLoop);

	Printer printer = new Printer(storage);

	Thread.yield();

	printer.run();

	}



	}



	}




